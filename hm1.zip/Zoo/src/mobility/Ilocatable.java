package mobility;

public interface Ilocatable {
	public Point getLocation();
	public boolean setLocation(Point p);
}