package animals;
import mobility.Point;

public abstract class Chew extends Animal{
	
	public Chew(String name, Point location)
	{
		super(name,location);
	}
	
	public Chew(Point startLocation, int size, String color, int hoerSpeed, int verSpeed) {
		
		super(startLocation,size,color,hoerSpeed,verSpeed);
	}

	public abstract void chew();
	
	public void makeSound()
	{
		chew();
	}
	
	public double move(Point pointA)
	{
		double distance1 = calcDistance(pointA);
		if(distance1 > 0)
		{
			super.setLocation(pointA);
			super.setTotalDistance(distance1);
			this.weight -= (distance1 * weight * 0.00025);
		}
		return distance1;
	}

}
