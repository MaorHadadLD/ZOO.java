package food;

public enum EFoodType 
{
	MEAT, NOTFOOD, VEGETABLE;
}